#!/bin/bash -l
#
#
# This script starts a single-domain Delft3D-FLOW computation online with Delft3D-WAVE on Linux
#
#    BU SCC OpenMP (single node, multi-core) EXAMPLE
#

# Request 1 28-core nodes for a total of 28 cores
# Note there is no need to use the MPI queues for this - there are 
# LOTS more 28-core non-MPI nodes.  The MPI nodes only run jobs from 
# the MPI queues as they have an additional high speed networking 
# connection (Infiniband).  

#$ -pe omp 28
# time for the job
#$ -l h_rt=120:00:00
# Email when complete or there's a failure
#$ -m bea
# Join the stdout and stderr files
#$ -j y


# Load the modules
module load intel/2018
module load openmpi/3.1.1_intel-2018
module load netcdf/4.6.1_intel-2018
module load netcdf-fortran/4.4.4_intel-2018
module load delft3d/7545
# The delft3d module sets the D3D_HOME and ARCH
# environment variables.


argfile=config_d_hydro.xml #flow2d3d.ini
mdwfile=swan_main.mdw


# Start up the d_hydro executable
d_hydro.exe $argfile &

# WAVE will auto-launch SWAN.  MPI jobs automatically
# have an environment variable, NHOSTS, set which is detected.  As this
# won't exist in this job it will look for an environment variable,
# OMP_NUM_THREADS_SWAN, and use that to set the number of threads.
# The job has an environment variable, NSLOTS, that is set to the requested
# number of cores:
export OMP_NUM_THREADS_SWAN=$NSLOTS
wave.exe $mdwfile 2
