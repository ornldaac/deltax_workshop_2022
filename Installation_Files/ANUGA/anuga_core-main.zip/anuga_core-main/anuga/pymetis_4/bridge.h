void bridge_partMeshNodal(int *, int *, idxtype *, int *, int *, int *, int *, idxtype *, idxtype *);
