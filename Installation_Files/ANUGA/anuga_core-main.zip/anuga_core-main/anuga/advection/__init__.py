"""
    A simple implementation of the shallow wave equation, mainly for test
    purposes.
"""
from __future__ import absolute_import

from .advection import Advection_Domain

from numpy.testing import Tester
test = Tester().test



