"""
    operator classes for ANUGA.
    
"""

from numpy.testing import Tester
test = Tester().test




