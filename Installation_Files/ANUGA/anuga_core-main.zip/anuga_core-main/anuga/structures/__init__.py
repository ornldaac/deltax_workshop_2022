

from numpy.testing import Tester
test = Tester().test

