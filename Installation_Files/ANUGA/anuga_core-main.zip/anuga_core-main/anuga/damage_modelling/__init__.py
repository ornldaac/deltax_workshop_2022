"""Make directory available as a Python package
"""

from numpy.testing import Tester
test = Tester().test




